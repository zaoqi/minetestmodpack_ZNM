Minetest mod "Crafting"
=======================
version: 2.0.2

License of Textures: CC-BY-NC-SA 4.0(https://creativecommons.org/licenses/by-nc-sa/4.0/)
License of source code: AGPL-3.0
------------------------------------
Copyright (c) 2016 Zaoqi

--USING the mod--
=================
This mod changes the players inventory (survival and creative) with more slots (9*4 instead of 8*4)
Like known from Minecraft you have a 2x2 crafting grid at inventory now. Furthermore a categorized creative
inventory and a support for stu's 3d armor mod (To use the armor and a preview of player).

Left items in the crafting slots are dropped infront of you.

Workbench
=========
With following recipe you craft a workbench (aka crafting table):

wood wood
wood wood

The workbench has a 3x3 crafting grid, that allows to use all recipes.
