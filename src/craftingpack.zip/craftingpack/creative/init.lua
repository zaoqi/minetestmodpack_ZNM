creative = {}

creative.set_creative_formspec = function()

end

minetest.register_on_player_receive_fields(function(player, formname, fields)

end)